package com.example.coffeeshop.Models;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    final static String DBName = "food.db";
    final static int DBVERSION = 11;
    public DBHelper(@Nullable Context context){
        super (context, DBName, null, DBVERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(
                "create table cart" +
                        "(id integer primary key autoincrement," +
                        "price int ," +
                        "image int," +
                        "foodname text, " +
                        "quantity int)"
        );

        sqLiteDatabase.execSQL(
                "create table customer" +
                        "(id integer primary key autoincrement," +
                        "name text, " +
                        "phone text," +
                        "payment text," +
                        "time text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP table if exists cart");
        sqLiteDatabase.execSQL("DROP table if exists customer");
        onCreate(sqLiteDatabase);
    }

    public boolean insertOrder(int price, int image, String foodName, int quantity) {
        SQLiteDatabase database = getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("price", price);
        values.put("image", image);
        values.put("foodname", foodName);
        values.put("quantity", quantity);
        long id = database.insert("cart", null, values);
        if (id <= 0){
            return false;
        }
        else return true;
    }

    public boolean insertCustomer(String name, String phone, String payment,String time) {
        SQLiteDatabase database = getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("phone", phone);
        values.put("payment", payment);
        values.put("time", time);
        long id = database.insert("customer", null, values);
        if (id <= 0){
            return false;
        }
        else return true;
    }


    public double getTotalPrice(){
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor c = database.rawQuery("Select SUM(price) FROM cart", null);
        if(c.moveToFirst())
        { return c.getDouble(0);
        }
        return 0;
    }
    public ArrayList<orderModelClass> getOrders() {
        ArrayList<orderModelClass> orders = new ArrayList<>();
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery("Select id, foodname, image, price, quantity from cart", null);
        if (cursor.moveToFirst()) {
            do {
                orderModelClass model = new orderModelClass();
                model.setOrderNumber(cursor.getInt(0) + "");
                model.setOrderedItem(cursor.getString(1));
                model.setOrderImage(cursor.getInt(2));
                model.setPrice(cursor.getInt(3) + "");
                model.setQuantity(cursor.getInt(4) + "");
                orders.add(model);
            } while (cursor.moveToNext());
        }
        cursor.close();
        database.close();
        return orders;
    }
    public void deleteARow(String id){
        SQLiteDatabase db= this.getWritableDatabase();
        db.delete("cart", "id" + " = ?", new String[] { id });
        db.close();
    }


}
