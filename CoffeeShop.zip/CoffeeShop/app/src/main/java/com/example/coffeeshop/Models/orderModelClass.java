package com.example.coffeeshop.Models;

public class orderModelClass {
    int orderImage;
    String orderedItem, price, orderNumber, quantity;

    public orderModelClass(){

    }
    public orderModelClass(int orderImage, String orderedItem, String price, String orderNumber, String quantity) {
        this.orderImage = orderImage;
        this.orderedItem = orderedItem;
        this.quantity = quantity;
        this.price = price;
        this.orderNumber = orderNumber;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public int getOrderImage() {
        return orderImage;
    }

    public void setOrderImage(int orderImage) {
        this.orderImage = orderImage;
    }

    public String getOrderedItem() {
        return orderedItem;
    }

    public void setOrderedItem(String orderedItem) {
        this.orderedItem = orderedItem;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }
}
