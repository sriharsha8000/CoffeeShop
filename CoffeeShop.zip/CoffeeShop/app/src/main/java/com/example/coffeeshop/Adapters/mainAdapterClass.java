package com.example.coffeeshop.Adapters;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coffeeshop.DetailsActivity;
import com.example.coffeeshop.Models.*;
import com.example.coffeeshop.R;
import java.util.*;
import android.content.*;
import android.view.*;


public class mainAdapterClass extends RecyclerView.Adapter<mainAdapterClass.viewholder>{
    ArrayList<mainModelClass> list;
    Context context;

    public mainAdapterClass(ArrayList<mainModelClass> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(context).inflate(R.layout.menu, parent, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewholder holder, int position){
        final mainModelClass model = list.get(position);
        holder.mainName.setText(model.getName());
        holder.drinkImage.setImageResource(model.getImage());
        holder.price.setText(model.getPrice());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DetailsActivity.class);
                intent.putExtra("image", model.getImage());
                intent.putExtra("price", model.getPrice());
                intent.putExtra("name", model.getName());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount(){
        return list.size();
    }

    public class viewholder extends RecyclerView.ViewHolder{
        ImageView drinkImage;
        TextView mainName, price;

        public viewholder(@NonNull View itemView){
            super(itemView);

            drinkImage = itemView.findViewById(R.id.imageView3);
            mainName = itemView.findViewById(R.id.name);
            price = itemView.findViewById(R.id.textView5);
        }
    }

}
