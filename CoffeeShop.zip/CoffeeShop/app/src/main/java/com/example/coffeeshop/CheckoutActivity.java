package com.example.coffeeshop;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.coffeeshop.Models.DBHelper;
import com.example.coffeeshop.databinding.ActivityCheckoutBinding;

import java.util.Calendar;

public class CheckoutActivity extends AppCompatActivity {
    ActivityCheckoutBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCheckoutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Spinner spinner =findViewById(R.id.paymentSpinner);
        setSpinner(spinner);

        DBHelper helper = new DBHelper(this);

        binding.totalPrice.setText(String.valueOf(helper.getTotalPrice()));
        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    boolean isInserted = helper.insertCustomer(
                            binding.nameField.getText().toString(),
                            binding.phoneField.getText().toString(),
                            binding.paymentSpinner.getSelectedItem().toString(),
                            Calendar.getInstance().getTime().toString()
                    );
                    if (isInserted) Toast.makeText(CheckoutActivity.this, "Successfully added to cart", Toast.LENGTH_SHORT).show();
                    else Toast.makeText(CheckoutActivity.this, "Error!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void setSpinner(Spinner spinner){
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this, R.array.paymentMethod, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
    }


}