package com.example.coffeeshop;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.coffeeshop.Models.DBHelper;
import com.example.coffeeshop.databinding.ActivityDetailsBinding;

public class DetailsActivity extends AppCompatActivity {
    ActivityDetailsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final int image = getIntent().getIntExtra("image", 0);
        final int price = Integer.parseInt(getIntent().getStringExtra("price"));
        final String name = getIntent().getStringExtra("name");

        binding.detaiImage.setImageResource(image);
        binding.priceView.setText(String.format("%d", price));
        binding.foodName.setText(name);
        binding.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int new_quantity =  Integer.parseInt(binding.quantity.getText().toString()) + 1;
                binding.quantity.setText(String.format("%d", new_quantity));
            }
        });

        binding.subtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int curr_quantity = Integer.parseInt(binding.quantity.getText().toString());
                if (curr_quantity >= 1) {
                    int new_quantity = curr_quantity - 1;
                    binding.quantity.setText(String.format("%d", new_quantity));
                } else Toast.makeText(DetailsActivity.this, "Cannot go lower!", Toast.LENGTH_SHORT);
            }
        });

        DBHelper helper = new DBHelper(this);
        binding.cartButton.setOnClickListener(view -> {
          boolean isInserted = helper.insertOrder(
                    price,
                    image,
                    name,
                    Integer.parseInt(binding.quantity.getText().toString()) );
           if (isInserted) Toast.makeText(DetailsActivity.this, "Successfully added to cart", Toast.LENGTH_SHORT).show();
           else Toast.makeText(DetailsActivity.this, "Error!", Toast.LENGTH_SHORT).show();
        });

    }
}