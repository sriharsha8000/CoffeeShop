package com.example.coffeeshop;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.coffeeshop.Adapters.orderAdapterClass;
import com.example.coffeeshop.Models.DBHelper;
import com.example.coffeeshop.Models.orderModelClass;
import com.example.coffeeshop.databinding.ActivityOrderBinding;

import java.util.ArrayList;

public class OrderActivity extends AppCompatActivity {
    ActivityOrderBinding binding;
    private DBHelper helper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOrderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        helper = new DBHelper(this);
        ArrayList<orderModelClass> list = helper.getOrders();


        orderAdapterClass adapter = new orderAdapterClass(list, this);
        binding.orderRecyclerView.setAdapter(adapter);


        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.orderRecyclerView.setLayoutManager(layoutManager);

        binding.checkoutButton.setOnClickListener(view -> {
            startActivity(new Intent(OrderActivity.this, CheckoutActivity.class));
        });
        Log.d("price", String.format("%s ", helper.getTotalPrice()));
        }



}