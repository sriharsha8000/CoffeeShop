package com.example.coffeeshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.coffeeshop.Adapters.mainAdapterClass;
import com.example.coffeeshop.Adapters.orderAdapterClass;
import com.example.coffeeshop.databinding.ActivityMainBinding;

import java.util.ArrayList;
import com.example.coffeeshop.Models.mainModelClass;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ArrayList<mainModelClass> list = new ArrayList<mainModelClass>();
        list.add(new mainModelClass(R.drawable.cold_brew, "Cold Brew", "6"));
        list.add(new mainModelClass(R.drawable.cookie, "Cookie", "2"));
        list.add(new mainModelClass(R.drawable.latte, "Latte", "4"));
        list.add(new mainModelClass(R.drawable.espresso, "Espresso", "3"));
        mainAdapterClass adapter = new mainAdapterClass(list, this);
        binding.recyclerview.setAdapter(adapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.recyclerview.setLayoutManager(layoutManager);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
     getMenuInflater().inflate(R.menu.menu, menu);
     return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item){
        switch (item.getItemId()){
            case R.id.orders:
                startActivity(new Intent(MainActivity.this, OrderActivity.class));
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}