package com.example.coffeeshop.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.coffeeshop.Models.DBHelper;
import com.example.coffeeshop.Models.orderModelClass;
import com.example.coffeeshop.R;

import java.util.ArrayList;

public class orderAdapterClass extends RecyclerView.Adapter<orderAdapterClass.viewHolder>{
    ArrayList<orderModelClass> list;
    static Context context;
    DBHelper db;

    public orderAdapterClass(ArrayList<orderModelClass> list, Context context) {
        this.list = list;
        this.context = context;
    }


    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.order_sample, parent, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
        final orderModelClass model = list.get(position);
        holder.orderImage.setImageResource(model.getOrderImage());
        holder.price.setText(model.getPrice());
        holder.orderedItem.setText(model.getOrderedItem());
        holder.quantity.setText(model.getQuantity());
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        ImageView orderImage;
        TextView orderedItem, price, quantity;
        ImageButton deleteButton;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            orderImage = itemView.findViewById(R.id.orderImageName);
            price = itemView.findViewById(R.id.orderPrice);
         //   orderNumber = itemView.findViewById(R.id.orderNumber);
            orderedItem = itemView.findViewById(R.id.itemName);
            quantity = itemView.findViewById(R.id.quantityView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    db = new DBHelper(context);
                    db.deleteARow(list.get(getAdapterPosition()).getOrderNumber());
                    list.remove(getAdapterPosition());
                    Toast.makeText(orderAdapterClass.context, "you have clicked Row " + getAdapterPosition(), Toast.LENGTH_LONG).show();
                    notifyItemRemoved(viewHolder.this.getLayoutPosition());
                }
            });
        }

    }
}


